﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto2
{
    public partial class Tela_Mercado : Form
    {
        public Tela_Mercado()
        {
            InitializeComponent();
        }
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();

            produtos.Produto = txtProduto.Text;
            produtos.Preco = txtPreco.Text;

            if (!txtProduto.Text.Equals("") || !txtPreco.Text.Equals(""))
            {
                bool CadastroProduto = produtos.CadastroProduto();
                if (CadastroProduto)
                {
                    MessageBox.Show("Produto Cadastrado com sucesso");
                }
            }
        }



        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                string produto = txtProduto.Text;
                string preco = txtPreco.Text;



            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private int IdProduto;
        private void dtgProdutos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow linha = dtgProdutos.Rows[e.RowIndex];
                    IdProduto = Convert.ToInt32(dtgProdutos.Rows[e.RowIndex].Cells["id"].Value);
                    txtProduto.Text = linha.Cells["produto"].Value.ToString();
                    txtPreco.Text = linha.Cells["preco"].Value.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Tela_Mercado_Load(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();
            produtos.ListarProdutos(dtgProdutos);
        }
    }
}
