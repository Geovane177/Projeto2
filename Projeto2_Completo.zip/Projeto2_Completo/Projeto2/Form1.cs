using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace Projeto2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuarios usuario = new Usuarios();

                usuario.Nome = txtNome.Text;
                usuario.Senha = txtSenha.Text;

                if (!txtNome.Text.Equals("") || !txtSenha.Text.Equals(""))
                {
                    bool Cadastro = usuario.CadastroUsuario();
                    if (Cadastro)
                    {
                        MessageBox.Show("Cadastro realizado com sucesso");
                        Tela_Mercado tela_Mercado = new Tela_Mercado();
                        tela_Mercado.Show();
                        this.Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar Usuario " + ex.Message);
            }
        }

        private void lklLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }
    }
}
