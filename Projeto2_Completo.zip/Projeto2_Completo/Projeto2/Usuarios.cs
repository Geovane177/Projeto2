﻿using Microsoft.VisualBasic.Logging;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2
{
    class Usuarios
    {
        private string nome;
        private string senha;
       
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        public string Senha
        {
            get { return senha;  }
            set { senha = value; }
        }

        public bool CadastroUsuario()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDB().Conectar())
                {

                    string inserir = "insert into usuarios (nome, senha) value (@nome, @senha)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);

                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@senha", senha);

                    int resultado = comando.ExecuteNonQuery();

                    if(resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar usuario" + ex.Message);
                return false;
            }
        }
        public bool Logar()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDB().Conectar())
                {
                  
                    string query = "SELECT * FROM usuarios WHERE nome = @nome AND senha = @senha";

                    MySqlCommand comando = new MySqlCommand(query, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@senha", senha);

                    int resultado = Convert.ToInt32(comando.ExecuteScalar());

                    if (resultado > 0)
                    {
                        MessageBox.Show("Login realizado com sucesso");
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro no catch logar" + ex.Message);
                return false;
            }
        }

    }
}
