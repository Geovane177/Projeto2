﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto2
{
    class Produtos
    {
        private string produto;
        private string preco;

        public string Produto
        {
            get { return produto;  }
            set { produto = value; }
        }

        public string Preco
        {
            get { return preco; }
            set { preco = value; }
        }

        public bool CadastroProduto()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDB().Conectar())
                {

                    string inserir = "insert into produtos (nomeProduto, preco) value (@nomeProduto, @preco)";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);

                    comando.Parameters.AddWithValue("@Nomeproduto", produto);
                    comando.Parameters.AddWithValue("@preco", preco);

                    int resultado = comando.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar produto" + ex.Message);
                return false;
            }
        }

        public bool ListarProdutos(DataGridView dataGrid)
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDB().Conectar())
                {
                    string listar = "select * from produtos";
                    MySqlCommand comando = new MySqlCommand(listar, conexaoBanco);
                    MySqlDataAdapter adaptador = new MySqlDataAdapter(comando);
                    DataTable tabela = new DataTable();
                    adaptador.Fill(tabela);
                    dataGrid.DataSource = tabela;

                    // Configurações do DataGridView
                    dataGrid.AllowUserToAddRows = false;  // Impede a adição de novas linhas manualmente
                    dataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;  // Ajusta as colunas automaticamente
                    dataGrid.AutoResizeColumns();  // Redimensiona as colunas
                    dataGrid.ClearSelection();  // Limpa a seleção das células

                    if (dataGrid.Rows.Count > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao listar produtos. " + ex.Message);
                return false;
            }
        }

    }
}
