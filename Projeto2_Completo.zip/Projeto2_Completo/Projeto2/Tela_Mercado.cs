﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Projeto2
{
    public partial class Tela_Mercado : Form
    {
        public Tela_Mercado()
        {
            InitializeComponent();
        }
        [DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HTCAPTION = 0x2;

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();

            produtos.Produto = txtProduto.Text;
            produtos.Preco = txtPreco.Text;

            if (!txtProduto.Text.Equals("") || !txtPreco.Text.Equals(""))
            {
                bool CadastroProduto = produtos.CadastroProduto();
                if (CadastroProduto)
                {
                    MessageBox.Show("Produto Cadastrado com sucesso");
                    produtos.ListarProdutos(dtgProdutos);
                }
            }
        }





        private int IdProduto;
        private void dtgProdutos_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow linha = dtgProdutos.Rows[e.RowIndex];
                    IdProduto = Convert.ToInt32(dtgProdutos.Rows[e.RowIndex].Cells["id"].Value);
                    txtProduto.Text = linha.Cells["nomeProduto"].Value.ToString();
                    txtPreco.Text = linha.Cells["preco"].Value.ToString();
                    txtId.Text = IdProduto.ToString();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Tela_Mercado_Load(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();
            produtos.ListarProdutos(dtgProdutos);
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();
            produtos.ListarProdutos(dtgProdutos);
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                string produto = txtProduto.Text;
                string preco = txtPreco.Text;

                if (IdProduto > 0)
                {
                    if (produto != "" && preco != "")
                    {
                        string conexaoBanco = "Server=localhost; Database=mercado; Uid=root; pwd=''; ";
                        MySqlConnection conexao = new MySqlConnection(conexaoBanco);

                        conexao.Open();

                        string AtualizarProduto = "UPDATE produtos SET nomeProduto = @nomeProduto, preco = @preco WHERE id = @id";
                        MySqlCommand comando = new MySqlCommand(AtualizarProduto, conexao);

                        comando.Parameters.AddWithValue("@nomeProduto", produto);
                        comando.Parameters.AddWithValue("@preco", preco);
                        comando.Parameters.AddWithValue("@id", IdProduto);

                        comando.ExecuteNonQuery();
                        MessageBox.Show("Produto editado com sucesso!");

                        conexao.Close();
                    }
                }
                else
                {
                    MessageBox.Show("Selecione um produto primeiro");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar dados! " + ex.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {

                if (IdProduto > 0)
                {

                    
                    var resultado = MessageBox.Show("Você quer excluir esse produto??", "Confirmar excluasão", MessageBoxButtons.YesNo);
                    if (resultado == DialogResult.Yes)
                    {
                        string conexaoBanco = "Server=localhost; Database=mercado; Uid=root; pwd=''; ";
                        MySqlConnection conexao = new MySqlConnection(conexaoBanco);
                        conexao.Open();



                        string DeletarAluno = "Delete from produtos where id = @id;";
                        MySqlCommand comando = new MySqlCommand(DeletarAluno, conexao);

                        comando.Parameters.AddWithValue("@id", IdProduto);

                        comando.ExecuteNonQuery();

                        MessageBox.Show("livro excluido com sucesso.");
                                         
                    }
                    else
                    {
                        MessageBox.Show("Produto não foi excluido.");
                    }

                }
                else
                {
                    MessageBox.Show("Selecione um lproduto");
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show("Erro ao excluir Produto!" + ex.Message);
            }
        }
    }
}

